import SwiftUI

struct SignupView: View {
    @State private var fullName: String = ""
    @State private var email: String = ""
    @State private var phoneNumber: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var role: String = "user" // default role

    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""

    @State private var navigateToLogin: Bool = false

    let roles = ["user", "lawyer"]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    Text("Create Account")
                        .font(.system(size: 32, weight: .bold))
                        .padding(.top, 30)

                    // MARK: - Input Fields
                    Group {
                        CustomTextField(label: "Full Name", placeholder: "Enter your name", text: $fullName)
                        CustomTextField(label: "Email", placeholder: "Enter your email", text: $email, keyboardType: .emailAddress)
                        CustomTextField(label: "Phone Number", placeholder: "Enter your phone number", text: $phoneNumber, keyboardType: .phonePad)

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Password")
                                .font(.headline)
                                .foregroundColor(.gray)

                            ZStack(alignment: .trailing) {
                                Group {
                                    if isPasswordVisible {
                                        TextField("Enter your password", text: $password)
                                    } else {
                                        SecureField("Enter your password", text: $password)
                                    }
                                }
                                .padding()
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(10)

                                Button(action: {
                                    isPasswordVisible.toggle()
                                }) {
                                    Image(systemName: isPasswordVisible ? "eye.slash" : "eye")
                                        .foregroundColor(.gray)
                                        .padding()
                                }
                            }
                        }

                        // MARK: - Role Picker
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Role")
                                .font(.headline)
                                .foregroundColor(.gray)

                            Picker("Role", selection: $role) {
                                ForEach(roles, id: \.self) {
                                    Text($0.capitalized)
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                        }
                    }

                    // MARK: - Signup Button
                    Button(action: handleSignup) {
                        Text("Sign Up")
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }

                    // MARK: - Hidden NavigationLink
                    NavigationLink(destination: LoginView(), isActive: $navigateToLogin) {
                        EmptyView()
                    }

                    Spacer()
                }
                .padding()
            }
            .navigationBarHidden(true)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Signup"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    // MARK: - Signup Handler
    func handleSignup() {
        if fullName.isEmpty || email.isEmpty || phoneNumber.isEmpty || password.isEmpty {
            alertMessage = "All fields are required."
            showAlert = true
            return
        }

        guard isValidEmail(email) else {
            alertMessage = "Invalid email format."
            showAlert = true
            return
        }

        guard isValidPhone(phoneNumber) else {
            alertMessage = "Invalid phone number."
            showAlert = true
            return
        }

        // Adjust this URL to your backend path
        let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/signup.php")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let body = "full_name=\(fullName)&email=\(email)&phone_number=\(phoneNumber)&password=\(password)&role=\(role)"
        request.httpBody = body.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    alertMessage = "Network error: \(error.localizedDescription)"
                    showAlert = true
                    return
                }

                guard let data = data else {
                    alertMessage = "No response from server."
                    showAlert = true
                    return
                }

                do {
                    if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        if let success = json["success"] as? Bool, success {
                            alertMessage = "Signup successful!"
                            navigateToLogin = true
                        } else {
                            alertMessage = json["error"] as? String ?? "Unknown error occurred."
                        }
                    } else {
                        alertMessage = "Invalid response format."
                    }
                } catch {
                    alertMessage = "Failed to parse response."
                }

                showAlert = true
            }
        }.resume()
    }

    func isValidEmail(_ email: String) -> Bool {
        let pattern = #"^\S+@\S+\.\S+$"#
        return NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: email)
    }

    func isValidPhone(_ number: String) -> Bool {
        let pattern = #"^\d{10,15}$"#
        return NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: number)
    }
}

// MARK: - Reusable Text Field
struct CustomTextField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.headline)
                .foregroundColor(.gray)

            TextField(placeholder, text: $text)
                .keyboardType(keyboardType)
                .autocapitalization(.none)
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(10)
        }
    }
}


// MARK: - Preview
#Preview {
    SignupView()
}
