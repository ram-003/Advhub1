import SwiftUI

// Model
struct BookingRequest: Identifiable, Decodable {
    let id: Int
    let lawyer_id: Int
    let lawyer_name: String
    let user_name: String
    let user_phone: String
    let appointment_date: String
    let appointment_time: String
    let practice_area: String
    let status: String
    let created_at: String
}

// Top-level response
struct AppointmentsResponse: Decodable {
    let success: Bool
    let appointments: [BookingRequest]
}

struct BookingScreen: View {
    let userName: String
    let userPhone: String
    let lawyerID: String

    @State private var bookingRequests: [BookingRequest] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    var body: some View {
        VStack {
            Text("Booking Requests")
                .font(.largeTitle)
                .padding()

            if isLoading {
                ProgressView("Loading...")
                    .padding()
            } else if let errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            } else {
                List(bookingRequests) { request in
                    VStack(alignment: .leading, spacing: 8) {
                        Text("User: \(request.user_name)").font(.headline)
                        Text("Phone: \(request.user_phone)").font(.subheadline)
                        Text("Case: \(request.practice_area)").font(.subheadline)
                        Text("Date: \(request.appointment_date)").font(.subheadline)
                        Text("Time: \(request.appointment_time)").font(.subheadline)
                        Text("Status: \(request.status)")
                            .foregroundColor(
                                request.status == "Pending" ? .orange :
                                (request.status == "Accepted" ? .green : .red)
                            )

                        // Only show buttons if status is Pending
                        if request.status == "Pending" {
                            HStack {
                                Button(action: { updateStatus(request, status: "Accepted") }) {
                                    Text("Accept")
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.green)
                                        .foregroundColor(.white)
                                        .cornerRadius(8)
                                }
                                Button(action: { updateStatus(request, status: "Rejected") }) {
                                    Text("Reject")
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.red)
                                        .foregroundColor(.white)
                                        .cornerRadius(8)
                                }
                            }
                            .padding(.top, 8)
                        }
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.gray.opacity(0.1)))
                    .padding(.vertical, 4)
                }
            }

            Spacer()
        }
        .padding()
        .onAppear(perform: fetchBookings)
    }

    // Fetch appointments
    func fetchBookings() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/fetch_appointments.php") else {
            errorMessage = "Invalid URL"
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = "lawyer_id=\(lawyerID)".data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                self.isLoading = false
                if let error = error { self.errorMessage = "Network error: \(error.localizedDescription)"; return }
                guard let data = data else { self.errorMessage = "No data received"; return }

                do {
                    let decoded = try JSONDecoder().decode(AppointmentsResponse.self, from: data)
                    self.bookingRequests = decoded.appointments
                } catch {
                    self.errorMessage = "Failed to decode: \(error)"
                    if let raw = String(data: data, encoding: .utf8) { print("RAW JSON: \(raw)") }
                }
            }
        }.resume()
    }

    // Update status in database
    func updateStatus(_ request: BookingRequest, status: String) {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/update_appointment_status.php") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.httpBody = "appointment_id=\(request.id)&status=\(status)".data(using: .utf8)
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: req) { _, _, _ in
            DispatchQueue.main.async {
                fetchBookings() // Refresh list after status update
            }
        }.resume()
    }
}

struct BookingScreen_Previews: PreviewProvider {
    static var previews: some View {
        BookingScreen(userName: "John Doe", userPhone: "9876543210", lawyerID: "1")
    }
}
