import SwiftUI

struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""

    let roles = ["user", "lawyer"]
    @State private var selectedRole = "user"

    // Extra field for lawyer ID (optional)
    @State private var lawyerID: String = ""

    // Navigation
    @State private var navigateToSignup = false
    @State private var navigateToUserHome = false
    @State private var navigateToLawyerHome = false

    // Data to pass
    @State private var userID: Int = 0
    @State private var userName: String = ""
    @State private var userPhone: String = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                Text("AdvHub")
                    .font(.system(size: 32, weight: .bold))
                    .padding(.top, 40)

                // Role Picker
                VStack(alignment: .leading, spacing: 8) {
                    Text("Select Role")
                        .font(.headline)
                        .foregroundColor(.gray)

                    Picker("Select Role", selection: $selectedRole) {
                        ForEach(roles, id: \.self) { role in
                            Text(role.capitalized).tag(role)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }

                // Optional ID for lawyers
                if selectedRole == "lawyer" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Enter ID (optional)")
                            .font(.headline)
                            .foregroundColor(.gray)
                        TextField("Enter ID", text: $lawyerID)
                            .keyboardType(.numberPad)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(10)
                    }
                }

                // Email Input
                VStack(alignment: .leading, spacing: 8) {
                    Text("Email").font(.headline).foregroundColor(.gray)
                    TextField("Enter your email", text: $email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(10)
                }

                // Password Input
                VStack(alignment: .leading, spacing: 8) {
                    Text("Password").font(.headline).foregroundColor(.gray)
                    ZStack(alignment: .trailing) {
                        Group {
                            if isPasswordVisible {
                                TextField("Enter your password", text: $password)
                            } else {
                                SecureField("Enter your password", text: $password)
                            }
                        }
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(10)

                        Button(action: {
                            isPasswordVisible.toggle()
                        }) {
                            Image(systemName: isPasswordVisible ? "eye.slash" : "eye")
                                .foregroundColor(.gray)
                                .padding()
                        }
                    }
                }

                // Login Button
                Button(action: handleLogin) {
                    Text("Login")
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }

                // Signup Link
                HStack {
                    Text("Don't have an account?")
                    Button("Sign Up") {
                        navigateToSignup = true
                    }
                    .foregroundColor(.blue)
                }
                .font(.footnote)
                .padding(.bottom, 20)

                // Navigation Links
                NavigationLink(destination: SignupView(), isActive: $navigateToSignup) { EmptyView() }

                NavigationLink(
                    destination: LawyerListView(userID: userID, userName: userName, userPhone: userPhone),
                    isActive: $navigateToUserHome
                ) { EmptyView() }

                NavigationLink(
                    destination: BookingScreen(userName: userName, userPhone: userPhone, lawyerID: lawyerID),
                    isActive: $navigateToLawyerHome
                ) { EmptyView() }
            }
            .padding()
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Login Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    // MARK: - Handle Login
    func handleLogin() {
        guard !email.isEmpty, !password.isEmpty else {
            alertMessage = "Please enter both email and password."
            showAlert = true
            return
        }

        guard isValidEmail(email) else {
            alertMessage = "Invalid email address."
            showAlert = true
            return
        }

        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/login.php") else {
            alertMessage = "Invalid server URL."
            showAlert = true
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let params = [
            "email": email,
            "password": password,
            "role": selectedRole
        ]
        request.httpBody = params
            .map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")" }
            .joined(separator: "&")
            .data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                if let error = error {
                    alertMessage = "Network error: \(error.localizedDescription)"
                    showAlert = true
                    return
                }

                guard let data = data else {
                    alertMessage = "No response from server."
                    showAlert = true
                    return
                }

                do {
                    if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        if let success = json["success"] as? Bool, success {
                            // Assign dynamic values from server response
                            self.userID = json["id"] as? Int ?? 0
                            self.userName = json["name"] as? String ?? ""
                            self.userPhone = json["phone"] as? String ?? ""

                            // Navigate based on role
                            if selectedRole == "user" {
                                navigateToUserHome = true
                            } else {
                                navigateToLawyerHome = true
                            }
                        } else {
                            alertMessage = json["error"] as? String ?? "Login failed."
                            showAlert = true
                        }
                    } else {
                        alertMessage = "Invalid response format."
                        showAlert = true
                    }
                } catch {
                    alertMessage = "Failed to decode response."
                    showAlert = true
                }
            }
        }.resume()
    }

    func isValidEmail(_ email: String) -> Bool {
        let pattern = #"^\S+@\S+\.\S+$"#
        return NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: email)
    }
}

#Preview {
    LoginView()
}
