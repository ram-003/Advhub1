import SwiftUI

struct UserProfileView: View {
    let userID: Int // Passed from homepage
    let userPhone: String

    @State private var fullName: String = ""
    @State private var email: String = ""
    @State private var phone: String = ""
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var navigateToAppointments = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                if isLoading {
                    ProgressView("Loading...")
                        .padding()
                } else if let errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                } else {
                    // Profile Image
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .frame(width: 120, height: 120)
                        .foregroundColor(.blue)
                        .overlay(Circle().stroke(Color.blue, lineWidth: 3))
                        .shadow(radius: 7)
                        .padding(.top, 40)

                    // User Details
                    VStack(spacing: 12) {
                        Text(fullName)
                            .font(.title)
                            .fontWeight(.bold)

                        Text(email)
                            .font(.subheadline)
                            .foregroundColor(.gray)

                        Text(phone)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }

                    // Buttons
                    VStack(spacing: 15) {
                        // Appointments Button
                        Button(action: {
                            navigateToAppointments = true
                        }) {
                            Text("Appointments")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }

                        // Delete Account Button
                        Button(action: deleteAccount) {
                            Text("Delete Account")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.red)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal)
                }

                Spacer()
            }
            .padding()
            .onAppear(perform: fetchUser)

            // Hidden NavigationLink for programmatic navigation
            NavigationLink(
                destination: UserAppointmentListView(currentUserPhone: userPhone),
                isActive: $navigateToAppointments
            ) {
                EmptyView()
            }
        }
    }

    // MARK: - Networking
    func fetchUser() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/fetch_user.php") else {
            errorMessage = "Invalid URL"
            isLoading = false
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let bodyString = "user_id=\(userID)"
        request.httpBody = bodyString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                self.isLoading = false

                if let error = error {
                    self.errorMessage = "Network error: \(error.localizedDescription)"
                    return
                }

                guard let data = data else {
                    self.errorMessage = "No data received"
                    return
                }

                do {
                    if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        if let success = json["success"] as? Bool, success,
                           let user = json["user"] as? [String: Any] {
                            self.fullName = user["full_name"] as? String ?? ""
                            self.email = user["email"] as? String ?? ""
                            self.phone = user["phone_number"] as? String ?? ""
                        } else {
                            self.errorMessage = json["error"] as? String ?? "Failed to load user"
                        }
                    } else {
                        self.errorMessage = "Invalid response format"
                    }
                } catch {
                    self.errorMessage = "Failed to decode response"
                    print(String(data: data, encoding: .utf8) ?? "")
                }
            }
        }.resume()
    }

    func deleteAccount() {
        // Call PHP API to delete user
        print("Delete account tapped")
    }
}

#Preview {
    UserProfileView(userID: 1, userPhone: "9876543210")
}
