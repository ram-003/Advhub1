import SwiftUI

// Unique model for user appointments
struct UserAppointment: Identifiable, Decodable {
    let id: Int
    let lawyer_id: Int
    let lawyer_name: String
    let user_name: String
    let user_phone: String
    let appointment_date: String
    let appointment_time: String
    let practice_area: String
    let status: String?
    let created_at: String
}

// Top-level response
struct UserAppointmentsResponse: Decodable {
    let success: Bool
    let appointments: [UserAppointment]
}

struct UserAppointmentListView: View {
    let currentUserPhone: String  // Unique property

    @State private var userAppointments: [UserAppointment] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    var body: some View {
        VStack {
            Text("My Appointments")
                .font(.largeTitle)
                .padding()

            if isLoading {
                ProgressView("Loading...")
                    .padding()
            } else if let errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            } else if userAppointments.isEmpty {
                Text("No appointments found")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List(userAppointments) { appointment in
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Lawyer: \(appointment.lawyer_name)").font(.headline)
                        Text("Case: \(appointment.practice_area)").font(.subheadline)
                        Text("Date: \(appointment.appointment_date)").font(.subheadline)
                        Text("Time: \(appointment.appointment_time)").font(.subheadline)
                        Text("Status: \(appointment.status ?? "Pending")")
                            .foregroundColor(
                                (appointment.status ?? "Pending") == "Accepted" ? .green :
                                ((appointment.status ?? "Pending") == "Rejected" ? .red : .orange)
                            )
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.gray.opacity(0.1)))
                    .padding(.vertical, 4)
                }
            }

            Spacer()
        }
        .padding()
        .onAppear(perform: fetchUserAppointments)
    }

    func fetchUserAppointments() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/fetch_user_appointments.php") else {
            errorMessage = "Invalid URL"
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let bodyString = "user_phone=\(currentUserPhone)"
        request.httpBody = bodyString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                self.isLoading = false

                if let error = error {
                    self.errorMessage = "Network error: \(error.localizedDescription)"
                    return
                }

                guard let data = data else {
                    self.errorMessage = "No data received"
                    return
                }

                do {
                    let decoded = try JSONDecoder().decode(UserAppointmentsResponse.self, from: data)
                    self.userAppointments = decoded.appointments
                } catch {
                    self.errorMessage = "Failed to decode: \(error)"
                    if let raw = String(data: data, encoding: .utf8) {
                        print("RAW JSON: \(raw)")
                    }
                }
            }
        }.resume()
    }
}

struct UserAppointmentListView_Previews: PreviewProvider {
    static var previews: some View {
        UserAppointmentListView(currentUserPhone: "9876543210")
    }
}
