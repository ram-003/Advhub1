import SwiftUI

struct LawyerDetailView: View {
    let lawyerID: String
    let userName: String
    let userPhone: String // Passed from home page
    @Environment(\.presentationMode) var presentationMode
    @State private var lawyer: LawyerDetail? = nil
    @State private var isLoading = true
    @State private var showBookingSheet = false

    var body: some View {
        ScrollView {
            if isLoading {
                ProgressView("Loading...")
                    .padding()
            } else if let l = lawyer {
                content(for: l)
            } else {
                Text("Failed to load details.")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .navigationBarHidden(true)
        .onAppear { fetchLawyerDetails() }
        .sheet(isPresented: $showBookingSheet) {
            if let l = lawyer {
                BookingSheet(
                    lawyerID: lawyerID,
                    lawyerName: l.name,
                    userName: userName,
                    userPhone: userPhone,
                    practiceAreas: l.practice_areas
                )
            }
        }
    }

    // MARK: - UI for Loaded Lawyer
    @ViewBuilder
    private func content(for l: LawyerDetail) -> some View {
        VStack(spacing: 20) {
            // Profile Image
            AsyncImage(url: URL(string: "http://14.139.187.229:8081/mca/adv_hub/uploads/\(l.profile_image ?? "")")) { phase in
                switch phase {
                case .success(let img): img.resizable()
                case .failure(_): Image(systemName: "person.crop.circle.fill").resizable()
                default: ProgressView()
                }
            }
            .scaledToFill()
            .frame(width: 140, height: 140)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.blue, lineWidth: 3))
            .shadow(radius: 7)
            .padding(.top, 30)

            // Name & Rating
            VStack(spacing: 8) {
                Text(l.name)
                    .font(.largeTitle)
                    .fontWeight(.bold)

                HStack(spacing: 4) {
                    let ratingDouble = Double(l.rating) ?? 0.0
                    Text(String(format: "%.1f", ratingDouble))
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.orange)
                    StarsView(rating: ratingDouble)
                    Text("\(l.reviews) Reviews")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
            }

            // Area of Practice
            VStack(alignment: .leading, spacing: 8) {
                Text("Area of Practice")
                    .font(.headline)
                ForEach(l.practice_areas, id: \.self) { area in
                    Text("• \(area)")
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // Biography
            VStack(alignment: .leading, spacing: 8) {
                Text("Biography")
                    .font(.headline)
                Text(l.biography)
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            // Extra Info
            HStack(spacing: 25) {
                VStack {
                    Label(l.location, systemImage: "mappin.and.ellipse")
                        .font(.subheadline)
                    Text("Location").font(.caption).foregroundColor(.gray)
                }
                VStack {
                    Label(l.experience, systemImage: "briefcase.fill")
                        .font(.subheadline)
                    Text("Experience").font(.caption).foregroundColor(.gray)
                }
                VStack {
                    Label(l.languages.joined(separator: ", "), systemImage: "globe")
                        .font(.subheadline)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                    Text("Languages").font(.caption).foregroundColor(.gray)
                }
            }
            .padding(.vertical, 20)

            // Buttons
            VStack(spacing: 15) {
                Button("Back to search") {
                    presentationMode.wrappedValue.dismiss()
                }
                .foregroundColor(.blue)
                .frame(maxWidth: .infinity)
                .padding()
                .overlay(RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.blue, lineWidth: 1.5))

                Button("Book now") {
                    showBookingSheet = true
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.green)
                .cornerRadius(10)
            }
            .padding(.bottom, 30)
        }
        .padding(.horizontal, 20)
    }

    // MARK: - Model
    struct LawyerDetail: Decodable {
        let id: Int
        let name: String
        let rating: String       // decoded as String from PHP
        let reviews: Int
        let practice_areas: [String]
        let biography: String
        let location: String
        let experience: String
        let languages: [String]
        let profile_image: String?
    }

    // MARK: - Networking
    func fetchLawyerDetails() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/fetch_lawyer_detail.php") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = "lawyer_id=\(lawyerID)".data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async { self.isLoading = false }

            if let error = error {
                print("Network error:", error)
                return
            }
            guard let data = data else { return }

            do {
                let decoded = try JSONDecoder().decode(LawyerDetail.self, from: data)
                DispatchQueue.main.async { self.lawyer = decoded }
            } catch {
                print("Decoding error:", error)
            }
        }.resume()
    }
}

// MARK: - Stars View
struct StarsView1: View {
    let rating: Double
    private let maxRating = 5
    var body: some View {
        HStack(spacing: 2) {
            ForEach(1...maxRating, id: \.self) { index in
                Image(systemName:
                        Double(index) <= rating.rounded(.down) ? "star.fill" :
                        (Double(index) - rating < 1 ? "star.lefthalf.fill" : "star")
                )
                .foregroundColor(.orange)
            }
        }
    }
}

// MARK: - Booking Sheet
struct BookingSheet: View {
    let lawyerID: String
    let lawyerName: String
    let userName: String
    let userPhone: String
    let practiceAreas: [String]

    @Environment(\.dismiss) var dismiss
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()
    @State private var selectedArea: String = ""
    @State private var isLoading = false
    @State private var alertMessage: String = ""
    @State private var showAlert = false

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Select Date & Time")) {
                    DatePicker("Date", selection: $selectedDate, displayedComponents: .date)
                    DatePicker("Time", selection: $selectedTime, displayedComponents: .hourAndMinute)
                }

                Section(header: Text("Select Area of Practice")) {
                    Picker("Area", selection: $selectedArea) {
                        ForEach(practiceAreas, id: \.self) { area in
                            Text(area)
                        }
                    }
                }

                Section {
                    Button("Confirm Appointment") {
                        bookAppointment()
                    }
                    .disabled(selectedArea.isEmpty)
                }
            }
            .navigationTitle("Book Appointment")
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Message"), message: Text(alertMessage), dismissButton: .default(Text("OK"), action: {
                    if alertMessage.contains("success") { dismiss() }
                }))
            }
        }
    }

    func bookAppointment() {
        isLoading = true
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: selectedDate)

        dateFormatter.dateFormat = "HH:mm:ss"
        let timeString = dateFormatter.string(from: selectedTime)

        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/save_appointment.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let body = "lawyer_id=\(lawyerID)&lawyer_name=\(lawyerName)&user_name=\(userName)&user_phone=\(userPhone)&appointment_date=\(dateString)&appointment_time=\(timeString)&practice_area=\(selectedArea)"
        request.httpBody = body.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async { isLoading = false }

            if let error = error {
                alertMessage = "Network error: \(error.localizedDescription)"
                showAlert = true
                return
            }

            guard let data = data else { return }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let success = json["success"] as? Bool, success {
                        alertMessage = json["message"] as? String ?? "Appointment booked successfully"
                    } else {
                        alertMessage = json["error"] as? String ?? "Failed to book appointment"
                    }
                    showAlert = true
                }
            } catch {
                alertMessage = "Failed to parse response"
                showAlert = true
            }
        }.resume()
    }
}

// MARK: - Preview
struct LawyerDetailView_Previews: PreviewProvider {
    static var previews: some View {
        LawyerDetailView(lawyerID: "1", userName: "John Doe", userPhone: "9876543210")
    }
}
