import SwiftUI

struct SplashScreen: View {
    @State private var isActive: Bool = false
    @State private var scaleEffect: CGFloat = 0.8
    @State private var opacity: Double = 0.5

    var body: some View {
        NavigationStack {
            ZStack {
                // Background Color
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.9), Color.indigo]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    // App Icon or Symbol
                    Image(systemName: "scales") // ⚖️ law-related SF Symbol
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .foregroundColor(.white)
                        .scaleEffect(scaleEffect)
                        .opacity(opacity)
                        .onAppear {
                            withAnimation(.easeIn(duration: 1.2)) {
                                self.scaleEffect = 1.0
                                self.opacity = 1.0
                            }
                        }

                    // App Title
                    Text("AdvHub")
                        .font(.system(size: 38, weight: .bold))
                        .foregroundColor(.white)
                        .opacity(opacity)
                        .onAppear {
                            withAnimation(.easeIn(duration: 1.2).delay(0.3)) {
                                self.opacity = 1.0
                            }
                        }

                    // Tagline (Optional)
                    Text("Find Your Legal Expert")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.85))
                        .padding(.top, 4)
                }
            }
            // ✅ Navigation to Login after delay
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
            .navigationDestination(isPresented: $isActive) {
                LoginView()
            }
        }
    }
}

#Preview {
    SplashScreen()
}
