//
//  AdvHubbApp.swift
//  AdvHubb
//
//  Created by SAIL on 22/09/25.
//

import SwiftUI
import SwiftData

@main
struct AdvHubbApp: App {
   

    var body: some Scene {
        WindowGroup {
            LoginView()
        }
       
    }
}
