import SwiftUI

struct Lawyer: Identifiable, Decodable {
    let id: String       // Using database ID
    let name: String
    let experience: Int
    let rating: Double
}

struct LawyerListView: View {
    // Passed from Login
    let userID: Int        // Add userID for navigation
    let userName: String
    let userPhone: String
    
    @State private var lawyers: [Lawyer] = []
    @State private var searchText: String = ""
    @State private var navigateToProfile = false

    // Filtered list
    var filteredLawyers: [Lawyer] {
        if searchText.isEmpty {
            return lawyers
        } else {
            return lawyers.filter {
                $0.name.localizedCaseInsensitiveContains(searchText)
            }
        }
    }

    var body: some View {
        NavigationStack {
            VStack {
                // Show user info at the top
                HStack {
                    VStack(alignment: .leading) {
                        Text("Welcome, \(userName)")
                            .font(.headline)
                        Text("📞 \(userPhone)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 10)

                // Search bar + Profile icon
                HStack {
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Search lawyers...", text: $searchText)
                            .textInputAutocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    .padding(8)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(10)

                    Button(action: {
                        navigateToProfile = true
                    }) {
                        Circle()
                            .fill(Color.blue.opacity(0.3))
                            .frame(width: 40, height: 40)
                            .overlay(
                                Text(String(userName.prefix(1)))
                                    .font(.headline)
                                    .foregroundColor(.blue)
                            )
                    }
                    .padding(.leading, 8)
                }
                .padding([.horizontal, .top])

                // List of lawyers
                List(filteredLawyers) { lawyer in
                    NavigationLink(destination: LawyerDetailView(lawyerID: lawyer.id,userName: userName, userPhone: userPhone)) {
                        LawyerRow(lawyer: lawyer)
                    }
                }
                .listStyle(.plain)
            }
            .navigationTitle("Lawyers")
            .onAppear {
                fetchLawyers()
            }

            // NavigationLink for profile page
            NavigationLink(
                destination: UserProfileView(userID: userID, userPhone: userPhone),
                isActive: $navigateToProfile
            ) {
                EmptyView()
            }
        }
    }

    // ✅ Fetch from PHP backend
    func fetchLawyers() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/fetch_lawyers.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST" // using form-data as asked

        let body = "action=get_lawyers"
        request.httpBody = body.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let data = data {
                do {
                    let decoded = try JSONDecoder().decode([Lawyer].self, from: data)
                    DispatchQueue.main.async {
                        self.lawyers = decoded
                    }
                } catch {
                    print("Decoding Error: \(error)")
                }
            } else if let error = error {
                print("Network Error: \(error)")
            }
        }.resume()
    }
}

// MARK: - Row View
struct LawyerRow: View {
    let lawyer: Lawyer
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Circle()
                .fill(Color.blue.opacity(0.2))
                .frame(width: 50, height: 50)
                .overlay(
                    Text(String(lawyer.name.prefix(1)))
                        .font(.headline)
                        .foregroundColor(.blue)
                )

            VStack(alignment: .leading, spacing: 5) {
                Text(lawyer.name)
                    .font(.headline)
                
                Text("Experience: \(lawyer.experience) years")
                    .font(.subheadline)
                    .foregroundColor(.gray)

                HStack(spacing: 4) {
                    Text(String(format: "%.1f", lawyer.rating))
                        .font(.subheadline)
                        .foregroundColor(.orange)
                    StarsView(rating: lawyer.rating)
                }
            }
        }
        .padding(.vertical, 8)
    }
}

struct StarsView: View {
    let rating: Double
    private let maxRating = 5

    var body: some View {
        HStack(spacing: 2) {
            ForEach(1...maxRating, id: \.self) { index in
                Image(systemName:
                        Double(index) <= rating.rounded(.down) ? "star.fill" :
                        (Double(index) - rating < 1 ? "star.lefthalf.fill" : "star")
                )
                .foregroundColor(.orange)
            }
        }
    }
}

// MARK: - Detail View
struct LawyerDetailView11: View {
    let lawyerID: String
    @State private var lawyer: Lawyer?

    var body: some View {
        VStack {
            if let lawyer = lawyer {
                Text(lawyer.name)
                    .font(.largeTitle)
                    .padding()
                
                Text("Experience: \(lawyer.experience) years")
                    .font(.title2)
                    .padding(.bottom, 5)
                
                Text("Rating: \(String(format: "%.1f", lawyer.rating)) ⭐️")
                    .font(.title3)
                    .foregroundColor(.orange)
            } else {
                ProgressView("Loading...")
            }
        }
        .onAppear {
            fetchLawyerDetails()
        }
    }

    func fetchLawyerDetails() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/adv_hub/fetch_lawyer_details.php?id=\(lawyerID)") else { return }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let data = data {
                do {
                    let decoded = try JSONDecoder().decode(Lawyer.self, from: data)
                    DispatchQueue.main.async {
                        self.lawyer = decoded
                    }
                } catch {
                    print("Decoding Error: \(error)")
                }
            } else if let error = error {
                print("Network Error: \(error)")
            }
        }.resume()
    }
}

#Preview {
    LawyerListView(userID: 1, userName: "John Doe", userPhone: "9876543210")
}
