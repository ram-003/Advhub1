//
//  AdvHubbTests.swift
//  AdvHubbTests
//
//  Created by SAIL on 22/09/25.
//

import Testing
@testable import AdvHubb

struct AdvHubbTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
