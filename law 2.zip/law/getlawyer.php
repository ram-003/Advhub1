<?php
header('Content-Type: application/json');

require_once 'config.php';  // This uses the shared connection

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed.']);
    exit();
}

// Fetch all lawyers
$sql = "SELECT * FROM lawyer";
$result = $conn->query($sql);

$lawyers = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $lawyers[] = $row;
    }

    echo json_encode(['success' => true, 'data' => $lawyers]);
} else {
    echo json_encode(['success' => true, 'data' => []]);
}

$conn->close();
?>
