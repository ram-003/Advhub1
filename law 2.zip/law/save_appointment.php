<?php
header('Content-Type: application/json');
require_once 'config.php';

// Get POST data
$lawyer_id      = $_POST['lawyer_id'] ?? '';
$lawyer_name    = $_POST['lawyer_name'] ?? '';
$user_name      = $_POST['user_name'] ?? '';
$user_phone     = $_POST['user_phone'] ?? '';
$appointment_date = $_POST['appointment_date'] ?? '';
$appointment_time = $_POST['appointment_time'] ?? '';
$practice_area  = $_POST['practice_area'] ?? '';

if (empty($lawyer_id) || empty($lawyer_name) || empty($user_name) || empty($user_phone) || empty($appointment_date) || empty($appointment_time) || empty($practice_area)) {
    echo json_encode(["success" => false, "error" => "Missing fields"]);
    exit;
}

// Prepare and insert
$stmt = $conn->prepare("INSERT INTO appointments (lawyer_id, lawyer_name, user_name, user_phone, appointment_date, appointment_time, practice_area) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssss", $lawyer_id, $lawyer_name, $user_name, $user_phone, $appointment_date, $appointment_time, $practice_area);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Appointment booked successfully"]);
} else {
    echo json_encode(["success" => false, "error" => "Failed to book appointment"]);
}

$stmt->close();
$conn->close();
?>
