<?php
// config.php

$host = "localhost";        // Replace with your database host if needed
$dbname = "LawApp";         // Your database name
$username = "root";         // Your DB username
$password = "";             // Your DB password

// Create database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
