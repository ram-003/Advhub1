<?php
header("Content-Type: application/json");

// Include your database config file
require_once "config.php";

// Check for POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $name = $_POST['name'] ?? '';
    $experience = $_POST['experience'] ?? '';
    $rating = $_POST['rating'] ?? '';
    $number = $_POST['number'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate required fields
    if (empty($name) || empty($experience) || empty($rating) || empty($number) || empty($email) || empty($password)) {
        echo json_encode([
            "success" => false,
            "error" => "All fields are required."
        ]);
        exit;
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Check if email already exists
    $checkStmt = $conn->prepare("SELECT id FROM lawyer WHERE email = ?");
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo json_encode([
            "success" => false,
            "error" => "Email already exists."
        ]);
        exit;
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO lawyer (name, experience, rating, number, email, password) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $experience, $rating, $number, $email, $hashedPassword);

    if ($stmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Lawyer added successfully."
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "error" => "Failed to insert lawyer."
        ]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        "success" => false,
        "error" => "Invalid request method."
    ]);
}
