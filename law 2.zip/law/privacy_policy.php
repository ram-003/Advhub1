<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - AdvHub</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f4f4f4;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1,
        h2 {
            color: #2c3e50;
        }

        p,
        ul {
            line-height: 1.6;
        }

        ul {
            padding-left: 20px;
        }

        footer {
            text-align: center;
            margin-top: 40px;
            color: #777;
            font-size: 0.9em;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Privacy Policy</h1>

        <p>
            This Privacy Policy explains how AdvHub (“we”, “our”, “us”) collects, uses,
            and protects your personal information when you use our application and services.
        </p>

        <h2>1. Information We Collect</h2>
        <ul>
            <li>Your name, email address, phone number, and profile details.</li>
            <li>Appointment and booking information.</li>
            <li>Device and usage data to improve service quality.</li>
        </ul>

        <h2>2. How We Use Your Information</h2>
        <ul>
            <li>To create and manage user accounts and appointments.</li>
            <li>To communicate important updates and service notifications.</li>
            <li>To enhance security and improve user experience.</li>
        </ul>

        <h2>3. Data Sharing</h2>
        <p>
            We do not sell or rent your personal data. We may share information only:
        </p>
        <ul>
            <li>With lawyers and users to facilitate bookings.</li>
            <li>When required by law or to protect our legal rights.</li>
        </ul>

        <h2>4. Data Security</h2>
        <p>
            We use reasonable technical and administrative measures to protect your data
            against unauthorized access or disclosure.
        </p>

        <h2>5. Your Rights</h2>
        <p>
            You may request access, correction, or deletion of your personal information
            by contacting our support team.
        </p>

        <h2>6. Policy Updates</h2>
        <p>
            We may update this Privacy Policy periodically. Updates will be posted on this page
            with the effective date.
        </p>

        <footer>
            &copy; 2025 AdvHub. All Rights Reserved.
        </footer>
    </div>
</body>

</html>
