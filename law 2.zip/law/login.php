<?php
header('Content-Type: application/json');

require_once 'config.php';  // Database connection

// Get POST data
$email = $_POST['email'] ?? '';
$pass = $_POST['password'] ?? '';
$role = $_POST['role'] ?? '';

if (empty($email) || empty($pass) || empty($role)) {
    echo json_encode(["success" => false, "error" => "Missing fields"]);
    exit;
}

// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("SELECT id, full_name, phone_number, password, role FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    echo json_encode(["success" => false, "error" => "Invalid credentials"]);
    exit;
}

$stmt->bind_result($id, $full_name, $phone_number, $hashed_password, $db_role);
$stmt->fetch();

// Check role matches and password verifies
if ($db_role !== $role) {
    echo json_encode(["success" => false, "error" => "Role mismatch"]);
    exit;
}

if (password_verify($pass, $hashed_password)) {
    // Return success with id, full name, and phone number
    echo json_encode([
        "success" => true,
        "id" => $id,
        "name" => $full_name,
        "phone" => $phone_number
    ]);
} else {
    echo json_encode(["success" => false, "error" => "Invalid credentials"]);
}

$stmt->close();
$conn->close();
?>
