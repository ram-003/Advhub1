<?php
// add_booking.php

// Enable debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

require_once 'config.php';  // This uses the shared connection

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST requests allowed']);
    exit;
}

// Required fields
$required = ['lawyeremail','useremail','name','dateAndTime'];
foreach ($required as $field) {
    if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
        echo json_encode(['success' => false, 'error' => "Field '{$field}' is required"]);
        exit;
    }
}

// Sanitize
$lawyeremail = trim($_POST['lawyeremail']);
$useremail = trim($_POST['useremail']);
$name = trim($_POST['name']);
$dateAndTime = trim($_POST['dateAndTime']);

// Optionally validate email format
if (!filter_var($lawyeremail, FILTER_VALIDATE_EMAIL) || !filter_var($useremail, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'One or both emails are invalid']);
    exit;
}

// Prepare statement
$stmt = $conn->prepare("INSERT INTO booking (lawyeremail, useremail, name, dateAndTime) VALUES (?, ?, ?, ?)");
if (!$stmt) {
    echo json_encode(['success' => false, 'error' => 'Prepare failed: ' . $conn->error]);
    exit;
}

$stmt->bind_param("ssss", $lawyeremail, $useremail, $name, $dateAndTime);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Booking added successfully']);
} else {
    echo json_encode(['success' => false, 'error' => 'Execution failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
