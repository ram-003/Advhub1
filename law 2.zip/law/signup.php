<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
require_once 'config.php';  // This uses the shared connection

// Get form data
$fullName = $_POST['full_name'];
$email = $_POST['email'];
$phone = $_POST['phone_number'];
$password = $_POST['password'];
$role = $_POST['role'];

// Basic validation
if (empty($fullName) || empty($email) || empty($phone) || empty($password) || empty($role)) {
    http_response_code(400);
    echo json_encode(["error" => "All fields are required"]);
    exit();
}

// Hash password
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

// Insert into DB
$stmt = $conn->prepare("INSERT INTO users (full_name, email, phone_number, password, role) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $fullName, $email, $phone, $hashedPassword, $role);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    http_response_code(400);
    echo json_encode(["error" => "Email already exists or insertion failed"]);
}

$stmt->close();
$conn->close();
?>
