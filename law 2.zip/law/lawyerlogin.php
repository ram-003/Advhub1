<?php
header('Content-Type: application/json');

require_once 'config.php';  // This uses the shared connection

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit();
}

// Check if required fields are present
if (!isset($_POST['email']) || !isset($_POST['password'])) {
    echo json_encode(['success' => false, 'error' => 'Email and password are required']);
    exit();
}

$email = $_POST['email'];
$password = $_POST['password'];

// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM lawyer WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Check if lawyer exists
if ($result->num_rows === 1) {
    $lawyer = $result->fetch_assoc();

    // If password is hashed using password_hash
    if (password_verify($password, $lawyer['password'])) {
        unset($lawyer['password']); // Don't expose password in response
        echo json_encode(['success' => true, 'data' => $lawyer]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid password']);
    }

    // If password is stored in plain text (not recommended), use this instead:
    /*
    if ($password === $lawyer['password']) {
        unset($lawyer['password']);
        echo json_encode(['success' => true, 'data' => $lawyer]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
    }
    */
} else {
    echo json_encode(['success' => false, 'error' => 'No account found with that email']);
}

$conn->close();
?>
