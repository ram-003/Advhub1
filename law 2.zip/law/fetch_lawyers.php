<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

require_once 'config.php';  // This uses the shared connection

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'get_lawyers') {
    $sql = "SELECT id, name, experience, rating FROM lawyers";
    $result = $conn->query($sql);

    $lawyers = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $lawyers[] = [
                "id" => $row['id'],
                "name" => $row['name'],
                "experience" => (int)$row['experience'],
                "rating" => (float)$row['rating']
            ];
        }
    }
    echo json_encode($lawyers);
} else {
    echo json_encode(["error" => "Invalid request"]);
}

$conn->close();
?>
