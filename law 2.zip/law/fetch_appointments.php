<?php
header('Content-Type: application/json');
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false,'error'=>'Only POST allowed']);
    exit;
}

$lawyer_id = $_POST['lawyer_id'] ?? '';

if(empty($lawyer_id)){
    echo json_encode(['success'=>false,'error'=>'Lawyer ID required']);
    exit;
}

$stmt = $conn->prepare("SELECT id, lawyer_id, lawyer_name, user_name, user_phone, appointment_date, appointment_time, practice_area, status, created_at FROM appointments WHERE lawyer_id=?");
$stmt->bind_param("i", $lawyer_id);
$stmt->execute();
$result = $stmt->get_result();

$appointments = [];
while($row = $result->fetch_assoc()){
    $appointments[] = $row; // status now included
}

echo json_encode(['success'=>true,'appointments'=>$appointments]);

$stmt->close();
$conn->close();
?>
