<?php
// update_appointment_status.php
header('Content-Type: application/json');
require_once 'config.php'; // Your DB connection

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST requests allowed']);
    exit;
}

$required = ['appointment_id','status'];
foreach ($required as $field) {
    if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
        echo json_encode(['success' => false, 'error' => "$field is required"]);
        exit;
    }
}

$appointment_id = intval($_POST['appointment_id']);
$status = trim($_POST['status']);

if(!in_array($status, ['Accepted','Rejected'])){
    echo json_encode(['success' => false, 'error' => 'Invalid status']);
    exit;
}

$stmt = $conn->prepare("UPDATE appointments SET status=? WHERE id=?");
$stmt->bind_param("si", $status, $appointment_id);

if($stmt->execute()){
    echo json_encode(['success'=>true, 'message'=>'Status updated successfully']);
} else {
    echo json_encode(['success'=>false, 'error'=>$stmt->error]);
}

$stmt->close();
$conn->close();
?>
