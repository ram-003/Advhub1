<?php
header('Content-Type: application/json');
require_once 'config.php';  // Database connection

// Get the user_id from POST
$user_id = $_POST['user_id'] ?? '';

if (empty($user_id)) {
    echo json_encode(["success" => false, "error" => "User ID is required"]);
    exit;
}

// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["success" => true, "message" => "Account deleted successfully"]);
    } else {
        echo json_encode(["success" => false, "error" => "No user found with this ID"]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Failed to delete account"]);
}

$stmt->close();
$conn->close();
?>
    

