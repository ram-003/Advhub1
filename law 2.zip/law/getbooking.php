<?php
// get_bookings.php

header('Content-Type: application/json');
require_once 'config.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST requests allowed']);
    exit;
}

// Check required field
$lawyeremail = $_POST['lawyeremail'] ?? '';
if (empty($lawyeremail)) {
    echo json_encode(['success' => false, 'error' => 'lawyeremail is required']);
    exit;
}

// Optional: validate email format
if (!filter_var($lawyeremail, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Invalid lawyer email']);
    exit;
}

// Prepare and execute query
$stmt = $conn->prepare("SELECT id, lawyeremail, useremail, name, dateAndTime, area_of_practice, created_at FROM booking WHERE lawyeremail = ?");
$stmt->bind_param("s", $lawyeremail);
$stmt->execute();

$result = $stmt->get_result();
$bookings = [];

while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

echo json_encode(['success' => true, 'bookings' => $bookings]);

$stmt->close();
$conn->close();
?>
