<?php
header('Content-Type: application/json');
require_once 'config.php'; // Database connection

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST requests allowed']);
    exit;
}

// Get user_id from POST
$user_id = $_POST['user_id'] ?? '';
if (empty($user_id)) {
    echo json_encode(['success' => false, 'error' => 'User ID is required']);
    exit;
}

// Prepare statement
$stmt = $conn->prepare("SELECT id, full_name, email, phone_number FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => 'User not found']);
    exit;
}

$user = $result->fetch_assoc();
echo json_encode(['success' => true, 'user' => $user]);

$stmt->close();
$conn->close();
?>
