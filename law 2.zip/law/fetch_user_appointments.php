<?php
header('Content-Type: application/json');
require_once 'config.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false,'error'=>'Only POST allowed']);
    exit;
}

$user_phone = $_POST['user_phone'] ?? '';

if(empty($user_phone)){
    echo json_encode(['success'=>false,'error'=>'User phone required']);
    exit;
}

// Fetch appointments for this user
$stmt = $conn->prepare("SELECT id, lawyer_id, lawyer_name, user_name, user_phone, appointment_date, appointment_time, practice_area, status, created_at FROM appointments WHERE user_phone=?");
$stmt->bind_param("s", $user_phone);
$stmt->execute();
$result = $stmt->get_result();

$appointments = [];
while($row = $result->fetch_assoc()){
    $appointments[] = $row;
}

echo json_encode(['success'=>true,'appointments'=>$appointments]);

$stmt->close();
$conn->close();
?>
