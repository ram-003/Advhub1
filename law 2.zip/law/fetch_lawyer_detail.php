<?php
header('Content-Type: application/json');
require_once 'config.php';  // This uses the shared connection

if(isset($_POST['lawyer_id'])){
    $lawyer_id = $_POST['lawyer_id'];

    $sql = "SELECT id, name, CAST(rating AS DECIMAL(3,1)) AS rating, CAST(reviews AS UNSIGNED) AS reviews,
                   area_of_practice, biography, location, experience, languages, profile_image
            FROM lawyers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $lawyer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if($row = $result->fetch_assoc()){
        // Convert area_of_practice and languages into arrays
        $row['practice_areas'] = array_map('trim', explode(',', $row['area_of_practice']));
        $row['languages'] = array_map('trim', explode(',', $row['languages']));

        echo json_encode($row);
    } else {
        echo json_encode(['error' => 'Lawyer not found']);
    }
}
?>
